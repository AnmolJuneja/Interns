import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class TripsPage extends StatefulWidget {
  const TripsPage({Key? key}) : super(key: key);

  @override
  State<TripsPage> createState() => _TripsPageState();
}

class _TripsPageState extends State<TripsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        padding:
            EdgeInsets.only(top: 24.h, left: 37.w, bottom: 36.h, right: 20.w),
        height: 80.h,
        width: 375.w,
        color: Colors.white,
        child: Row(
          children: [
            Text('Scheduled',
                style: GoogleFonts.inter(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xff9F9F9F))),
            SizedBox(width: 51.w),
            Text('Completed',
                style: GoogleFonts.inter(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xff242424))),
            SizedBox(width: 53.w),
            Text(
              'Cancelled',
              style: GoogleFonts.inter(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: const Color(0xff808080)),
            )
          ],
        ),
      ),
    );
  }
}
